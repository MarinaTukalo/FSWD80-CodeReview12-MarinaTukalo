<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_marina_tukalo_traveler
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.0/css/bootstrap.min.css" integrity="sha384-SI27wrMjH3ZZ89r4o+fGIJtnzkAnFs3E4qz9DIYioCQ5l9Rd/7UAa8DHcaL8jkWt" crossorigin="anonymous">
	<!-- google fonts -->
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Barlow&display=swap" rel="stylesheet"> 

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'cr12_marina_tukalo_traveler' ); ?></a>

	<header id="masthead" class="site-header">
		<div class="site-branding">
			<?php
			the_custom_logo();
			if ( is_front_page() && is_home() ) :
				?>
				<h1 class="site-title text-center" style="font-family: 'Josefin Sans', sans-serif;"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color: #0c222a; font-size: 160%" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php
			else :
				?>
				<h1 class="site-title text-center" style="font-family: 'Josefin Sans', sans-serif;"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color: #0c222a; size: font-size: 160%" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php
			endif; 
			?>
		</div><!-- .site-branding -->
		
		<!-- navbar -->
		<div class="bg-light">
		<div class="d-flex justify-content-center">

		<nav class="navbar navbar-expand-md navbar-light" role="navigation">
		
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation"><?php esc_html_e( 'Primary Menu', 'cr12_marina_tukalo_traveler' ); ?>
			<span class="navbar-toggler-icon"></span>
		</button>
	<?php
        wp_nav_menu( array(
            'theme_location'    => 'primary',
            'depth'             => 2,
            'container'         => 'div',
            'container_class'   => 'collapse navbar-collapse',
            'container_id'      => 'bs-example-navbar-collapse-1',
            'menu_class'        => 'nav navbar-nav',
            'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
            'walker'            => new WP_Bootstrap_Navwalker(),
        ) );
    ?>
		</nav>
		</div>
	</div>
	</header>
	<img class="img-fluid" style="background-size: cover;" src="<?php echo get_template_directory_uri(); ?>/img/hero.jpg" alt="image">
	</div>	
	<div id="content" class="site-content mt-5">
